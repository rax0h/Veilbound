Family pack 01 — vegetation variants (not GS masters).
Unzip and merge assets/ into repo root.
