Veilbound GS pack 1 — environment + props. Unzip and merge assets/ into repo root.
