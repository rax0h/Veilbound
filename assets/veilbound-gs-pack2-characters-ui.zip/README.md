GS pack 2 characters UI atmosphere — transparent PNG isolates.
