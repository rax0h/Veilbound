Veilbound GS pack 2 — characters, creatures, atmosphere, UI. Unzip and merge assets/ into repo root.
