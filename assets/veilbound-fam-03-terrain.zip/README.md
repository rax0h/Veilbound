Family pack 03 — terrain patches, paths, overlays.
Unzip and merge assets/ into repo root.
