Family pack 02 — rocks and geological isolates.
Unzip and merge assets/ into repo root.
